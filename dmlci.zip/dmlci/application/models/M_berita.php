<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_berita extends CI_Model{

  public function __construct()
  {
    parent::__construct();
    $this->load->database();
    //Codeigniter : Write Less Do More
  }
  public function tampilkanberita()
  {
    $query=$this->db->get('berita');
    return $query->result_array();
  }
  public function tampilkansingle($where){
		 $query=$this->db->get_where('berita',$where);
     return $query->result_array();
	}
  public function tambahberita($data)
  {
    $this->db->insert('berita',$data);
  }
  function hapusberita($where){
		$this->db->where($where);
		$this->db->delete('berita');
	}
  function updateberita($where,$data){
		$this->db->where($where);
		$this->db->update('berita',$data);
	}

}
