<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="<?php echo base_url('assets/style.css') ?>">
    <title><?php echo $title; ?></title>
  </head>
  <body>
    <h1>TrisnoWlaharWetan.Net</h1>
    <div class="menu">
      <a href="<?php echo base_url() ?>">Home</a>
      <a href="<?php echo base_url('berita/tambahberita/') ?>">Tambah</a>

    </div>
