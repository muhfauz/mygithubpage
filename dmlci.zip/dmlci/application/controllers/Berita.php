<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Berita extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    $this->load->model('m_berita');
    $this->load->helper('url');
    $this->load->library('form_validation');
  }

  public function index()
  {
    $data['title']='Judul';
    $data['berita'] = $this->m_berita->tampilkanberita();
    $this->load->view('header',$data);
    $this->load->view('v_berita',$data);
    $this->load->view('footer',$data);
  }
  public function singleberita($slug)
  {
    $where = array('slug' => $slug);
    $data['berita'] = $this->m_berita->tampilkansingle($where);
    $data['title']=str_replace('-',' ',$slug);
    $this->load->view('header',$data);
    $this->load->view('v_single',$data);
    $this->load->view('footer',$data);

  }
  public function tambahberita()
  {
    $data['title']='Tambah Berita';
    $this->load->view('header',$data);
    $this->load->view('tambahberita');
    $this->load->view('footer');
  }
  public function aksitambahberita()
  {
    //Tangkap data dari forom
    $judul = $this->input->post('judul');
    $slug=str_replace(' ','-',$judul);
    $isiberita=$this->input->post('isiberita');


    //Form Validasi jika kosong
    $this->form_validation->set_rules('judul', 'Judul', 'required');
    $this->form_validation->set_rules('isiberita', 'Isi Berita', 'required');
    if($this->form_validation->run()!=false)
    {
      $data=array(
        'judul'=>$judul,
        'isi'=>$isiberita,
        'slug'=>$slug
      );
      $this->m_berita->tambahberita($data);
      redirect(base_url());

    }
    else {
      $data['title']='Tambah Berita';
      $this->load->view('header',$data);
      $this->load->view('tambahberita');
      $this->load->view('footer');
    }
  }
  public function hapusberita($slug)
  {
    $where = array('slug' => $slug);
		$this->m_berita->hapusberita($where);
    redirect(base_url());
  }
  public function editberita($slug)
  {
    $where = array('slug' => $slug);
    $data['berita'] = $this->m_berita->tampilkansingle($where);
    $data['title']='Edit '.str_replace('-',' ',$slug);
    $this->load->view('header',$data);
    $this->load->view('editberita',$data);
    $this->load->view('footer',$data);
  }
  public function aksieditberita($slug)
  {
    //Tangkap data dari forom
    $where = array('slug' => $slug);
    $judul = $this->input->post('judul');
    $slug=str_replace(' ','-',$judul);
    $isiberita=$this->input->post('isiberita');


    //Form Validasi jika kosong
    $this->form_validation->set_rules('judul', 'Judul', 'required');
    $this->form_validation->set_rules('isiberita', 'Isi Berita', 'required');
    if($this->form_validation->run()!=false)
    {
      $data=array(
        'judul'=>$judul,
        'isi'=>$isiberita,
        'slug'=>$slug
      );
      $this->m_berita->updateberita($where,$data);
      redirect(base_url());

    }
    else {
      $data['title']='Tambah Berita';
      $this->load->view('header',$data);
      $this->load->view('tambahberita');
      $this->load->view('footer');
    }
  }
}
