
    <?php foreach ($berita as $itemberita):?>
      <div class="judul_single">
          <h3><?php echo $itemberita['judul']; ?></h3>
      </div>
      <div class="konten_single">
      <p><?php echo $itemberita['isi']; ?></p>
      </div>


    <?php endforeach; ?>
