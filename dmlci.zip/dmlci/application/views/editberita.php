<?php echo validation_errors(); ?>
<?php foreach ($berita as $itemberita){
$judulawal=$itemberita['judul'];
$isiawal=$itemberita['isi'];
$slug=$itemberita['slug'];
} ?>


<form class="" action="<?php echo base_url('berita/aksieditberita/').$slug ?>" method="post">
<label for="">Judul</label><br>
<input type="text" name="judul" value="<?=$judulawal?>"><br>
<label for="">Isi Berita</label><br>
<textarea name="isiberita" rows="8" cols="80"><?=$isiawal?></textarea><br>
<input type="submit" name="submit" value="Proses">
</form>
