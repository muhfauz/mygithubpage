
    <?php foreach ($berita as $isiberita):?>

<div class="each_article">
    <h3><a href="<?php echo base_url('berita/singleberita/').$isiberita['slug'] ?>"><?php echo $isiberita['judul']; ?></a></h3>
    <p><?php echo $isiberita['isi']; ?>
    <a href="<?php echo base_url('berita/hapusberita/').$isiberita['slug'] ?>">Hapus</a>
    <a href="<?php echo base_url('berita/editberita/').$isiberita['slug'] ?>">Edit</a>
    </p>
</div>
  <?php endforeach; ?>
